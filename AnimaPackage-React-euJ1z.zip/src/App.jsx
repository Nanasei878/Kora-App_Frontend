import React from "react";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { Profil } from "./screens/Profil";

const router = createBrowserRouter([
  {
    path: "/*",
    element: <Profil />,
  },
]);

export const App = () => {
  return <RouterProvider router={router} />;
};
